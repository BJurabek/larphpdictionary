
<script type="text/javascript">

$(document).ready(function(){
  $('#sortable').sortable({
    axis: 'y',
    opacity: 0.5,
    placeholder: 'ui-state-default',
    containment: '.block',
    stop: function(){
      var par_id = $('#sortable').attr('data-id');
      var runame = $('.kod'+par_id).map(function(){return $(this).attr('data-id');}).get();
      //alert(arr);
      $.ajax({
        url: "{{route('save')}}",
        type: 'POST',
        data: {"_token":$('meta[name="csrf-token"]').attr('content'),par_id:par_id,runame:runame},
        error: function(){
          $('#res').text("Ошибка!");
        },
        success: function(){
          $('#res').show().text("Сохранено!").fadeOut(1000);
        }
      });
    }
  });


});

</script>
  <div class="row mb-2">
    <div class="col-md-12">
      <div class="row no-gutters rounded overflow-hidden flex-md-row mb-4 shadow-sm position-relative">
 @if($ruen)






        <div class="col-12 p-2 d-flex flex-column position-static ui-blog">
         <h5><a href="#" title="{{$ruen->enname}} ">{{$ruen->enname}}</a> &#9660;

 <div class='block'><ul id='sortable' data-id="{{$ruen->id}}">

  @foreach($ruen->runame as $z=>$name)
        <li id='{{$z}}' class='ui-state-default tclass kod{{$ruen->id}}' data-id="{{$name}}">{{$name}}</li>
  @endforeach

 </ul></div>

        </h5>
        </div>






@endif


      </div>
    </div>
  </div>