  <link type="text/css" href="css/jquery-ui-1.8.14.custom.css" rel="stylesheet" />


  <div class="row mb-2">
    <div class="col-md-12">
      <div class="row no-gutters rounded overflow-hidden flex-md-row mb-4 shadow-sm position-relative">



 @if($ruen)
<div id="accordion" role="tablist">
   @foreach($ruen as $k=>$ru)

  <div class="card">

    <div class="card-header" role="tab" id="heading{{$k}}">
      <h5 class="mb-0">
        <a class="collapsed" data-toggle="collapse" href="#collapse{{$k}}" aria-expanded="{{($k==0)?'true':'false'}}" aria-controls="collapse{{$k}}">{{$ru->enname}} &#9660;</a>
      </h5>
    </div>

   <div id="collapse{{$k}}" class="collapse {{($k==0)?'show':''}}" role="tabpanel" aria-labelledby="heading{{$k}}" data-parent="#accordion">
      <div class="card-body">
        @if(count($ru->runame)>1)  <div class='block'><ul id='sortable' data-id="{{$ru->id}}"> @endif
  @foreach($ru->runame as $z=>$name)
        <li id='{{$z}}' class='ui-state-default tclass kod{{$ru->id}}' data-id="{{$name}}">{{$name}}</li>
  @endforeach
@if(count($ru->runame)>1) </ul></div>   @endif
      </div>
    </div>
  </div>
 @endforeach
</div>
@endif

      </div>
    </div>
    </div>

    <script type="text/javascript">

$(document).ready(function(){
  $('#sortable').sortable({
    axis: 'y',
    opacity: 0.5,
    placeholder: 'ui-state-default',
    containment: '.block',
    stop: function(){
      var par_id = $('#sortable').attr('data-id');
      var runame = $('.kod'+par_id).map(function(){return $(this).attr('data-id');}).get();
      //alert(arr);
      $.ajax({
        url: "{{route('save')}}",
        type: 'POST',
        data: {"_token":$('meta[name="csrf-token"]').attr('content'),par_id:par_id,runame:runame},
        error: function(){
          $('#res').text("Ошибка!");
        },
        success: function(){
          $('#res').show().text("Сохранено!").fadeOut(1000);
        }
      });
    }
  });


});

</script>