<!DOCTYPE HTML>
<html lang="ru-RU">
<head>
  <title>{{ isset($title)?$title:'' }}</title>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compitable" content="IE=egde">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=480">
  <link rel="alternate" type="application/atom+xml" title="News" href="/feed">
  <meta name="description" content="{{ (isset($meta_desc)) ? $meta_desc : ''}}">
  <meta name="keywords" content="{{ (isset($keywords)) ? $keywords : ''}}">
  <meta name="author" content="{{ (isset($author)) ? $author : ''}}">
  <meta name="votdel" content="{{ (isset($votdel)) ? $votdel : ''}}">
  <meta name="csrf-token" content="{{ csrf_token() }}">

  <link rel="icon" href="{{ asset(env('THEME').'/img/favicon.ico')}}" sizes="192x192">
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    {!!Html::style(env('THEME').'/css/font-awesome.min.css')!!}
    <link rel="stylesheet" href="{{ asset(env('THEME').'/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset(env('THEME').'/css/font-awesome.min.css') }}">
    <link rel="stylesheet" href="{{ asset(env('THEME').'/css/style.css') }}">
    {!!Html::script(env('THEME').'/js/jquery-3.5.1.min.js')!!}
    {!!Html::style(env('THEME').'/css/jquery-ui.css')!!}

    <script src="/scripts/jquery.js" type="text/javascript"></script>
<script src="/scripts/jquery-ui.min.js" type="text/javascript"></script>


            <link href="/css/select2.css" rel="stylesheet"/>
    <script src="/js/select2.js"></script>

    <style>
    .select2-container{width: 100%!important;}
</style>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>



<body>


<div class="container">
  <header class="blog-header py-2">
    <div class="row flex-nowrap justify-content-between align-items-center">
      <div class="col-3 pt-1 d-none d-md-none d-lg-block">


<a href="/" class="text-muted">

<svg viewBox="0 0 651 115" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-16 w-auto text-gray-700 sm:h-20">
                        <g clip-path="url(#clip0)" fill="#EF3B2D">
                            <path d="M 21.852033,1.0001404 A 1.6783671,1.6798199 0 0 0 20.977707,1.2236592 L 0.8401709,12.827645 l -0.001167,0.0012 -0.001167,5.83e-4 c -0.0683601,0.0396 -0.1237799,0.09423 -0.18479089,0.142292 -0.054232,0.04241 -0.11575412,0.07816 -0.16377202,0.126223 -0.0581916,0.05826 -0.10061244,0.128735 -0.14976018,0.194888 -0.0372845,0.05032 -0.0830927,0.09561 -0.114728,0.149889 -0.0468879,0.08142 -0.0749565,0.171838 -0.1077217,0.260041 -0.01751239,0.04806 -0.04541163,0.09166 -0.0589696,0.141416 C 0.02024366,13.984933 0,14.132602 0,14.283 v 69.030201 c 0,0.601026 0.32075871,1.155709 0.84104667,1.45594 L 41.115826,107.97624 c 0.08813,0.0503 0.182972,0.0809 0.276748,0.11424 0.04406,0.0158 0.08471,0.0419 0.129908,0.0538 a 1.6834514,1.6849086 0 0 0 0.860899,0 c 0.03898,-0.0102 0.07456,-0.0335 0.112976,-0.047 0.09943,-0.0345 0.200178,-0.0673 0.293389,-0.12096 L 83.064234,84.769141 a 1.6783671,1.6798199 0 0 0 0.841046,-1.45594 V 61.274248 l 19.29649,-11.119257 a 1.6783671,1.6798199 0 0 0 0.84105,-1.45594 V 25.688888 a 1.7371184,1.7386221 0 0 0 -0.0599,-0.43769 c -0.0136,-0.04973 -0.0412,-0.09336 -0.0587,-0.141415 -0.0328,-0.08877 -0.0611,-0.178623 -0.10801,-0.260041 -0.0316,-0.05484 -0.0772,-0.09957 -0.11444,-0.149889 -0.0491,-0.06615 -0.091,-0.136648 -0.14976,-0.194886 -0.048,-0.04863 -0.10954,-0.08382 -0.16377,-0.126222 -0.0616,-0.04806 -0.11643,-0.102713 -0.18479,-0.142292 l -0.001,-5.99e-4 -0.001,-0.0012 -20.13812,-11.60457 a 1.6783671,1.6798199 0 0 0 -1.674502,0 l -20.137537,11.603401 -0.0012,0.0012 -0.0012,5.98e-4 c -0.06836,0.03958 -0.123489,0.09423 -0.1845,0.142293 -0.05423,0.04241 -0.116045,0.07816 -0.164063,0.126222 -0.05819,0.05824 -0.100321,0.129024 -0.149468,0.195177 -0.03728,0.05032 -0.08309,0.09532 -0.114728,0.149597 -0.04689,0.08142 -0.07525,0.172131 -0.108014,0.260333 -0.01751,0.04806 -0.04512,0.09137 -0.05868,0.141124 -0.03785,0.140786 -0.05809,0.288459 -0.05809,0.438858 V 47.72784 L 43.629625,57.397877 V 14.283 a 1.6947498,1.6962168 0 0 0 -0.05809,-0.438856 c -0.01356,-0.04976 -0.04146,-0.09336 -0.05897,-0.141416 -0.03277,-0.08877 -0.06083,-0.178623 -0.107723,-0.260041 -0.03164,-0.05485 -0.07744,-0.09957 -0.114727,-0.149889 -0.04915,-0.06615 -0.09101,-0.136649 -0.14976,-0.194885 -0.04802,-0.04862 -0.109541,-0.08382 -0.163772,-0.126223 -0.06158,-0.04806 -0.116437,-0.102714 -0.184791,-0.142292 l -0.0012,-5.84e-4 -8.97e-4,-0.0012 L 22.651918,1.2236592 A 1.6783671,1.6798199 0 0 0 21.852033,1.0001404 Z M 21.813791,4.6173466 38.587724,14.283 21.813791,23.948654 5.0395657,14.283 Z M 82.225814,16.024402 99.000039,25.690056 82.225814,35.35571 65.451881,25.690056 Z m -41.952201,1.163466 v 42.143666 l -9.734365,5.60959 -7.047158,4.060739 v -42.14425 l 9.734071,-5.608715 z m -36.918476,8.97e-4 7.046576,4.060446 9.734072,5.609007 v 45.049117 l 5.98e-4,0.0029 -5.98e-4,0.0035 c 0,0.06446 0.01805,0.12484 0.0254,0.188164 0.0096,0.08255 0.01211,0.166276 0.03357,0.245434 l 8.97e-4,0.0038 c 0.01808,0.06615 0.05313,0.125716 0.07911,0.189041 0.02881,0.07011 0.04975,0.1442 0.08816,0.209786 a 0.020337,0.0203546 0 0 0 0.0023,0.005 c 0.03446,0.05937 0.08429,0.1079 0.12553,0.162745 0.04576,0.05937 0.08412,0.124497 0.13779,0.177646 l 0.0044,0.0055 c 0.04745,0.04693 0.107458,0.08027 0.160561,0.121548 0.05988,0.04693 0.114044,0.100648 0.180703,0.139662 l 0.0073,0.0029 0.0064,0.0044 19.285689,10.924371 V 103.6166 L 3.355137,82.343159 Z m 60.41144,11.40618 7.047451,4.061029 9.734072,5.608715 v 19.133772 l -7.047452,-4.060738 -9.734071,-5.608715 z m 36.918473,0 V 47.729008 L 83.903529,57.398461 V 38.264668 l 9.734363,-5.608715 z m -38.596188,22.043044 16.763424,9.659517 -12.299542,7.026671 -24.60492,14.057726 -16.748536,-9.486839 17.58929,-10.135481 5.98e-4,-5.99e-4 z M 80.5481,63.197408 V 82.343159 L 43.629625,103.6166 V 84.289672 L 70.971086,68.668775 Z"/>
                        </g>
                    </svg>

            </a>


      </div>
      <div class="col-5">


        <form class="form-inline my-2 my-lg-0 blog-header-logo text-dark justify-content-center" method="post" action="{{route('emloyees.getEtog')}}">
            @csrf

      <input class="form-control mr-sm-2" id="autocomplete" type="text" name="myCountry" aria-label="Search" placeholder="Слово или словосочетание">
<input type='hidden' id='selectuser_id' name="id" />

      <button class="btn btn-outline-dark my-2 my-sm-0" type="submit"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="mx-3" role="img" viewBox="0 0 24 24" focusable="false"><title>Search</title><circle cx="10.5" cy="10.5" r="7.5"/><path d="M21 21l-5.2-5.2"/></svg></button>
    </form>


      </div>
      <div class="col-4 d-flex justify-content-end align-items-center">





         @if (Route::has('login'))
                    @auth
                        <a href="{{ url('/home') }}" class="text-sm text-gray-700 underline text-muted">Админ</a>
                        <!-- Authentication -->
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf

                            <x-dropdown-link :href="route('logout')"
                                    onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                {{ __('Log Out') }}
                            </x-dropdown-link>
                        </form>
                    @else
                        <a href="{{ route('login') }}" class="text-sm text-gray-700 underline text-muted">Вход</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}" class="ml-4 text-sm text-gray-700 underline text-muted">Регистрация</a>
                        @endif
                    @endauth
            @endif





      </div>
    </div>
  </header>

   <div class="clear"></div>




  @yield('content')


</div>









<footer class="blog-footer">
  <p><a class="text-muted" href="/">Laravel v{{ Illuminate\Foundation\Application::VERSION }} (PHP v{{ PHP_VERSION }})</a> </p>

</footer>










        <script src="{{ asset(env('THEME').'/js/bootstrap.min.js') }}"></script>
        <script src="{{ asset(env('THEME').'/js/main.js') }}"></script>


<script type="text/javascript">




 $( function() {
var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $( "#autocomplete" ).autocomplete({
            source: function( request, response ) {

                $.ajax({
                    url: "{{route('emloyees.getSearch')}}",
                    type: 'post',
                    dataType: "json",
                    data: {
                        search: request.term,
                        "_token":$('meta[name="csrf-token"]').attr('content')
                    },

                    // data: function(params){
                    //     return {
                    //         _token: CSRF_TOKEN,
                    //         search: params.term
                    //     };
                    // },
                    success: function( data ) {
                        response( data );
                    }
                });
            },
            select: function (event, ui) {
                $('#autocomplete').val(ui.item.label); // display the selected text
                $('#selectuser_id').val(ui.item.value); // save selected id to input
                return false;
            },
            focus: function(event, ui){
                $( "#autocomplete" ).val( ui.item.label );
                $( "#selectuser_id" ).val( ui.item.value );
                return false;
            },
        });


    });

    function split( val ) {
      return val.split( /,\s*/ );
    }
    function extractLast( term ) {
      return split( term ).pop();
    }

    </script>

</body>
</html>