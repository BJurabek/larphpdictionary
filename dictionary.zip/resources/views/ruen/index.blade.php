@extends(env('THEME').'.layouts.site')

@section('content')
	{!! $content !!}
@endsection