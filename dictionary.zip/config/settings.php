<?php
	return [
	'theme' => env('THEME','default'),
	'paginate_index' => 10
];
?>