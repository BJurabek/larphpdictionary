-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Авг 13 2021 г., 15:33
-- Версия сервера: 8.0.24
-- Версия PHP: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ruen`
--

-- --------------------------------------------------------

--
-- Структура таблицы `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_08_09_114421_create_ruen_table', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `ruen`
--

CREATE TABLE `ruen` (
  `id` bigint UNSIGNED NOT NULL,
  `enname` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `runame` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `ruen`
--

INSERT INTO `ruen` (`id`, `enname`, `runame`, `created_at`, `updated_at`) VALUES
(1, 'abate', '[\"уменьшать\"]', NULL, NULL),
(2, 'abatement', '[\"уменьшение\"]', NULL, NULL),
(3, 'absoluteaddress', '[\" абсолютный адрес, число, однозначно указывающее положение данных\", \" физический адрес\"]', NULL, NULL),
(4, 'absoluteassembler', '[\"абсолютный ассемблер\"]', NULL, NULL),
(5, 'absoluteaddressing', '[\"абсолютная адресация\"]', NULL, NULL),
(6, 'absolutebinarycode', '[\"абсолютный двоичный код\"]', NULL, NULL),
(7, 'absolute code', '[\" машинный код, программа в машинном коде\", \" программа в абсолютных адресах\"]', NULL, NULL),
(8, 'absolute coding', '[\"программирование в машинном коде\"]', NULL, NULL),
(9, 'absolute command', '[\"абсолютная команда (команда отображения, параметры которой интерпретируются как абсолютные координаты)\"]', NULL, NULL),
(10, 'absolutecoordinate', '[\"абсолютная координата\"]', NULL, NULL),
(11, 'absolutecoordinates', '[\"абсолютные координаты (координаты, идентифицирующие положение точки относительно заданной системы координат, общей для всего описания)\"]', NULL, NULL),
(12, 'absolute data', '[\"абсолютные данные (напр., значения действительных координат наэкране дисплея)\"]', NULL, NULL),
(13, 'absolute error', '[\"абсолютная ошибка; абсолютная погрешность, разность между точным и приближенным значениями\"]', NULL, NULL),
(14, 'absolute expression', '[\"абсолютное выражение (в программе на языке ассемблер)\"]', NULL, NULL),
(15, 'absoluteloader', '[\"абсолютный загрузчик (не выполняет настройку адресов)\"]', NULL, NULL),
(16, 'absolutepathname', '[\"полное составное имя\"]', NULL, NULL),
(17, 'absoluteprogram', '[\"программа в абсолютных адресах\"]', NULL, NULL),
(18, 'abstractbaseclass', '[\"базовый абстрактный класс\"]', NULL, NULL),
(19, 'abstractclass', '[\"абстрактный класс\"]', NULL, NULL),
(20, 'abstractcode', '[\"абстрактный код\"]', NULL, NULL),
(21, 'abstractdataobject', '[\"абстрактный информационный объект\"]', NULL, NULL),
(22, 'abstractdatatype', '[\"абстрактный тип данных\"]', NULL, NULL),
(23, 'ABT (ABorT)', '[\"отменить, прервать\"]', NULL, NULL),
(24, 'abuse', '[\"эксплуатация с нарушением норм\"]', NULL, NULL),
(25, 'ACCAP (AutocodertoCOBOLConversionAidProgram)', '[\"автокодер для вспомогательной программы преобразования Кобол \"]', NULL, NULL),
(26, 'AcceleratedGraphicPort (AGP)', '[\"ускоренный графический порт (графический стандарт для отображения трехмерных изображений)\"]', NULL, NULL),
(27, 'acceleration', '[\"ускорение\"]', NULL, NULL),
(28, 'accelerator', '[\"ускоритель, акселератор\"]', NULL, NULL),
(29, 'acceleratorkey', '[\"командная клавиша\"]', NULL, NULL),
(30, 'accentuation', '[\"выделение (текста)\"]', NULL, NULL),
(31, 'accept', '[\" ввод (с клавиатуры)\", \" согласие в сетевых протоколах;\",\"одобрять, принимать; accept all принять все\"]', NULL, NULL),
(32, 'acceptor', '[\"акцептор (получатель сообщения)\"]', NULL, NULL),
(33, 'accesories', '[\" вспомогательные программы (Microsoft Paint, Microsoft Word Pad)\", \" дополнительные устройства (модем, мышь, сканер), предназначенные для улучшения работы операционной системы или персонального компьютера\"]', NULL, NULL),
(34, 'ACCESS', '[\"пакет управления базами данных\"]', NULL, NULL),
(35, 'accessaddress', '[\"адрес доступа; указатель, ссылка\"]', NULL, NULL),
(36, 'access class', '[\"класс доступа\"]', NULL, NULL),
(37, 'accesscontrol', '[\"контроль доступа, управление доступом\"]', NULL, NULL),
(38, 'accesscontrolcategory', '[\"категория управления доступом\"]', NULL, NULL),
(39, 'accesscontrolentry', '[\"вход контроля доступа\"]', NULL, NULL),
(40, 'access controlequipment', '[\"аппаратура управления доступом\"]', NULL, NULL),
(41, 'accesscontrollist', '[\"список регулирования доступа\"]', NULL, NULL),
(42, 'accesscontrolmachine (ACM)', '[\"устройство управления доступом \"]', NULL, NULL),
(43, 'accesscontrolstore', '[\"накопитель управления доступом\"]', NULL, NULL),
(44, 'accesscontrolsystem', '[\"система контроля доступа\"]', NULL, NULL),
(45, 'accesscycle', '[\"цикл обращения\"]', NULL, NULL),
(46, 'accessdenialprobability', '[\"вероятность отказа в доступе\"]', NULL, NULL),
(47, 'accessdenied', '[\"доступ невозможен; вход в систему невозможен\"]', NULL, NULL),
(48, 'accessfeedernode', '[\"узел, обеспечивающий доступ (в сети)\"]', NULL, NULL),
(49, 'accessibility options (properties)', '[\"специальные возможности\"]', NULL, NULL),
(50, 'access key', '[\"клавиша доступа\"]', NULL, NULL),
(51, 'access keys', '[\"клавиши (быстрого) доступа\"]', NULL, NULL),
(52, 'access mechanism', '[\"механиз доступа\"]', NULL, NULL),
(53, 'accessmethod', '[\" метод доступа\", \" системная программа, реализующая метод доступа\"]', NULL, NULL),
(54, 'accessmode', '[\"режим доступа\"]', NULL, NULL),
(55, 'accessoutrageprobability', '[\"вероятность прерывания доступа\"]', NULL, NULL),
(56, 'access panel', '[\"пульт доступа\"]', NULL, NULL),
(57, 'access path', '[\"путь доступа\"]', NULL, NULL),
(58, 'access point', '[\"точка доступа\"]', NULL, NULL),
(59, 'access permission', '[\"право доступа\"]', NULL, NULL),
(60, 'accessrestriction', '[\"ограничение доступа\"]', NULL, NULL),
(61, 'accessright', '[\"право доступа\"]', NULL, NULL),
(62, 'accessrightlist', '[\"список прав доступа\"]', NULL, NULL),
(63, 'accesstechnique', '[\"метод доступа\"]', NULL, NULL),
(64, 'accesstime', '[\"\\u0432\\u0440\\u0435\\u043c\\u044f \\u043e\\u0431\\u0440\\u0430\\u0449\\u0435\\u043d\\u0438\\u044f \\u043a \\u042d\\u0412\\u041c; \\u0432\\u0440\\u0435\\u043c\\u044f \\u0434\\u043e\\u0441\\u0442\\u0443\\u043f\\u0430\",\"\\u0432\\u0440\\u0435\\u043c\\u044f \\u0432\\u044b\\u0431\\u043e\\u0440\\u043a\\u0438 \\u0438\\u0437 \\u043f\\u0430\\u043c\\u044f\\u0442\\u0438 \\u042d\\u0412\\u041c\"]', NULL, '2021-08-13 07:33:02'),
(65, 'access type', '[\"тип доступа\"]', NULL, NULL),
(66, 'access unit', '[\"блок доступа\"]', NULL, NULL),
(67, 'access violation', '[\"нарушение доступа\"]', NULL, NULL),
(68, 'accessorial', '[\"вспомогательный; дополнительный\"]', NULL, NULL),
(69, 'accessories', '[\"аксессуары\"]', NULL, NULL),
(70, 'accessory', '[\"дополнительное устройство, средство; аксессуар(ы)\"]', NULL, NULL),
(71, 'accessorykit', '[\"набор вспомогательных устройств\"]', NULL, NULL),
(72, 'accident', '[\"случайность; авария, сбой; byaccident случайно\"]', NULL, NULL),
(73, 'accidental', '[\"случайный\"]', NULL, NULL),
(74, 'accidental error', '[\"случайная ошибка\"]', NULL, NULL),
(75, 'ACCIS (Advisory Committee for the Coordination of Information Systems)', '[\"Консультативный комитет по координации информационных систем\"]', NULL, NULL),
(76, 'accomplish', '[\"выполнять, совершать; завершать; дополнять\"]', NULL, NULL),
(77, 'accomplished', '[\"законченный\"]', NULL, NULL),
(78, 'accomplishment', '[\"выполнение\"]', NULL, NULL),
(79, 'accord', '[\"согласие\"]', NULL, NULL),
(80, 'according to', '[\"в соотвествии с\"]', NULL, NULL),
(81, 'accordingly', '[\"соотвественно\"]', NULL, NULL),
(82, 'account', '[\" подсчет; расчет\", \" учетная запись; бюджет пользователя\",\"абонемент\",\"вести учет\"]', NULL, NULL),
(83, 'accountbalance', '[\"баланс на счету пользователя\"]', NULL, NULL),
(84, 'account lockout', '[\"блокировка учетной записи; блокировка бюджета\"]', NULL, NULL),
(85, 'account policy', '[\"политика учетных записей\"]', NULL, NULL),
(86, 'accountrestriction', '[\"ограничения на счет пользователя\"]', NULL, NULL),
(87, 'accounting', '[\" подсчет; расчет\", \" подсчитывающий\"]', NULL, NULL),
(88, 'accounting', '[\" учет системных ресурсов\", \" система расчетов\"]', NULL, NULL),
(89, 'accumulate', '[\"собирать, накапливать (данные)\"]', NULL, NULL),
(90, 'accumulation', '[\"сбор, накопление (данных)\"]', NULL, NULL),
(91, 'accumulator', '[\" аккумулятор\", \" сумматор; накапливающий регистратор\"]', NULL, NULL),
(92, 'accumulatorregister', '[\"накапливающий регистр\"]', NULL, NULL),
(93, 'accuracy', '[\"точность\"]', NULL, NULL),
(94, 'accurate', '[\"точный\"]', NULL, NULL),
(95, 'accuratedata', '[\"точные данные\"]', NULL, NULL),
(96, 'ACED (alternating current electroluminescent display)', '[\"электролюминесцентный дисплей переменного тока\"]', NULL, NULL),
(97, 'ACF (access control field)', '[\"поле управления доступом\"]', NULL, NULL),
(98, 'achieve', '[\"достигать\"]', NULL, NULL),
(99, 'achievement', '[\"достижение\"]', NULL, NULL),
(100, 'ACI (asynchronous communication interface)', '[\"асинхронный связной интерфейс\"]', NULL, NULL),
(101, 'ACIA (asynchronous communications interface adapter)', '[\"интерфейсный адаптер асинхронной связи\"]', NULL, NULL),
(102, 'ACID (automated classification and interpretation of data)', '[\"автоматическая классификация и интерпретация данных\"]', NULL, NULL),
(103, 'аcid', '[\"кислота\"]', NULL, NULL),
(104, 'ACK', '[\"символ подтверждения приёма (сокр. от acknowledge)\"]', NULL, NULL),
(105, 'acknowledge', '[\"подверждать (прием), квитировать\"]', NULL, NULL),
(106, 'acknowledgement', '[\"подтворждение (приема), квитирование\"]', NULL, NULL),
(107, 'ACL (AcessControlList)', '[\"список управления доступом\"]', NULL, NULL),
(108, 'ACM 1. (AssosiationforComputerMachinery)', '[\"Ассоциация по вычислительной технике\", \" (accesscontrolmachine) устройство управления доступом\"]', NULL, NULL),
(109, 'ACMS 1. (applicationcontrolandmanagementsystem)', '[\"система контроля и администрирования приложений\", \" (automatedconnectionmanagerserver) сервер автоматизированного управления соединениями \"]', NULL, NULL),
(110, 'A-constant', '[\"адресная константа\"]', NULL, NULL),
(111, 'acoustic', '[\"акустический\"]', NULL, NULL),
(112, 'acousticcoupler', '[\"устройство сопряжения на базе акустического модема\"]', NULL, NULL),
(113, 'acousticdataprocessing', '[\"обработка акустических данных\"]', NULL, NULL),
(114, 'acousticmodem', '[\"акустический модем\"]', NULL, NULL),
(115, 'acoustics', '[\"акустика\"]', NULL, NULL),
(116, 'ACOM (automaticcodingmachine)', '[\"автоматическое кодирующее устройство\"]', NULL, NULL),
(117, 'ACOS (automatic coding system)', '[\"система автоматического кодирования\"]', NULL, NULL),
(118, 'acquire', '[\"получать (данные, информацию)\"]', NULL, NULL),
(119, 'acquisition', '[\"получение\"]', NULL, NULL),
(120, 'dataacquisition', '[\"получение данных\"]', NULL, NULL),
(121, 'acquisitionprocessor', '[\"процессор сбора данных\"]', NULL, NULL),
(122, 'ACR (automaticcharacterrecognition)', '[\"автоматическое распознавание символов\"]', NULL, NULL),
(123, 'acrobat', '[\"акробат (один из форматов файла, широко используемый для хранения документов)\"]', NULL, NULL),
(124, 'across', '[\"через; по\"]', NULL, NULL),
(125, 'acting', '[\"действующий, работающий\"]', NULL, NULL),
(126, 'action', '[\" выполнение\", \" действие; работа (также о приборе)\"]', NULL, NULL),
(127, 'actionbar', '[\"полоса действий\"]', NULL, NULL),
(128, 'actionmedia', '[\"другое название видоплат (плат цифрового видеоинтерфейса)\"]', NULL, NULL),
(129, 'activate', '[\" активизировать, приводить в действие\", \" вызывать\"]', NULL, NULL),
(130, 'activation', '[\" активация; активизация\", \" вызов\"]', NULL, NULL),
(131, 'activationframe', '[\"кадр (запись) активации\"]', NULL, NULL),
(132, 'activationrecord', '[\"запись активации\"]', NULL, NULL),
(133, 'active', '[\"активный, находящийся в действии\"]', NULL, NULL),
(134, 'activecell', '[\"рабочая ячейка, активная ячейка\"]', NULL, NULL),
(135, 'activecodepage', '[\"активная кодовая страница\"]', NULL, NULL),
(136, 'activedesktop', '[\"активный рабочий стол \"]', NULL, NULL),
(137, 'activedisk', '[\"активный диск\"]', NULL, NULL),
(138, 'activefile', '[\"открытый файл, активный файл\"]', NULL, NULL),
(139, 'activehub', '[\"активный концентратор (хаб)\"]', NULL, NULL),
(140, 'activematrix', '[\"активная матрица\"]', NULL, NULL),
(141, 'activememory', '[\"активная память\"]', NULL, NULL),
(142, 'activepicture', '[\"текущий рисунок\"]', NULL, NULL),
(143, 'active program', '[\"активная программа, рабочая программа\"]', NULL, NULL),
(144, 'activetask', '[\"активная задача\"]', NULL, NULL),
(145, 'activewindow', '[\"активное окно, рабочее окно\"]', NULL, NULL),
(146, 'activeX', '[\"набор технологий, которые позволяют программам, не мешая друг другу, совместно работать в сети \"]', NULL, NULL),
(147, 'active X controls', '[\"элементы управления Active X\"]', NULL, NULL),
(148, 'activities journal', '[\"журнал текущей работы\"]', NULL, NULL),
(149, 'activities planner', '[\"планировщик работы\"]', NULL, NULL),
(150, 'activity', '[\"деятельность; обработка запроса, трансакция (transaction)\"]', NULL, NULL),
(151, 'activity-based management', '[\"операционное управление\"]', NULL, NULL),
(152, 'actual', '[\"действительный, реальный, фактический\"]', NULL, NULL),
(153, 'actualaddress', '[\"исполнительный адрес; абсолютный адрес\"]', NULL, NULL),
(154, 'actualparameter', '[\"фактический параметр\"]', NULL, NULL),
(155, 'actualsize', '[\"действительный (реальный) размер (страницы)\"]', NULL, NULL),
(156, 'actualstorage', '[\"физическая память\"]', NULL, NULL),
(157, 'actuality', '[\"действительность\"]', NULL, NULL),
(158, 'actually', '[\"действительно, фактически\"]', NULL, NULL),
(159, 'AD (analog-digital)', '[\"аналого цифровой\"]', NULL, NULL),
(160, 'ADAC (analog-digital-analogconverter)', '[\"аналого-цифро-аналоговый преобразователь\"]', NULL, NULL),
(161, 'ADACC (automaticdataacquisitionsystemandcomputercomplex)', '[\"комплекс из ЭВМ и автоматической системы сбора данных\"]', NULL, NULL),
(162, 'ADAM (autodecrementing adressing mode)', '[\"автодекрементный способ адресации\"]', NULL, NULL),
(163, 'ADAPS (automaticdisplayandplottingsystem)', '[\"автоматическая система вывода данных на дисплей и плоттер\"]', NULL, NULL),
(164, 'ADAPT (abstractdesignandprogrammingtranslator)', '[\"абстрактный транслятор для проектирования и программирования\"]', NULL, NULL),
(165, 'adapt', '[\"приспосабливать; адаптировать; настраивать\"]', NULL, NULL),
(166, 'adaptable', '[\"приспосабливаемый, настраиваемый, могущий быть приспособленным или настроенным\"]', NULL, NULL),
(167, 'adaptable links', '[\"настраиваемые связи\"]', NULL, NULL),
(168, 'adaptation', '[\"адаптация, приспособление\"]', NULL, NULL),
(169, 'adapter', '[\" адаптер; переходное устройство; сопрягающее устройство\", \" плата расширения\"]', NULL, NULL),
(170, 'adaptererror', '[\"ошибка адаптера\"]', NULL, NULL),
(171, 'adapterdescriptionfile', '[\"файл описания адаптера\"]', NULL, NULL),
(172, 'adapterinterface', '[\"интерфейс адаптера\"]', NULL, NULL),
(173, 'adaptive', '[\"адаптивный\"]', NULL, NULL),
(174, 'adaptivearchitecture', '[\"адаптивная архитектура\"]', NULL, NULL),
(175, 'adaptivecontrolsystem', '[\"адаптивная система управления\"]', NULL, NULL),
(176, 'adaptivedatacompression', '[\"адаптивный протокол сжатия данных\"]', NULL, NULL),
(177, 'adaptivedifferentialpulsecodemodulation (ADPCM)', '[\"адаптивная дифференциальная импульсно-кодовая модуляция\"]', NULL, NULL),
(178, 'adaptivesystem', '[\"адаптивная система\"]', NULL, NULL),
(179, 'adaptivity', '[\"адаптивность\"]', NULL, NULL),
(180, 'ADAS 1. (automaticdataacquisitionsystem)', '[\"система автоматического сбора данных\", \" (automaticdataanalisissystem) система автоматического анализа данных\"]', NULL, NULL),
(181, 'ADB (AppleDesktopBus)', '[\"коммуникационный порт для подключения устройств ввода информации в компьютерах Macintosh\"]', NULL, NULL),
(182, 'ADC 1. (analog-digital conversion)', '[\"преобразование из аналоговой формы в цифровую\", \" (analogdigitalconverter) аналого-цифровой преобразователь (АЦП)(устройство для преобразования аналогового сигнала в цифровой код;выполняется, как правило,в виде интегральной микросхемы)\"]', NULL, NULL),
(183, 'ADCC (analog-to-digitalconvertercontroller)', '[\"контроллер аналого-цифрового преобразователя\"]', NULL, NULL),
(184, 'ADCСP (advanceddatacommunicationcontrolprotocol)', '[\"улучшенный протокол управления передачей данных\"]', NULL, NULL),
(185, 'ADD (automaticdrawingdigitizing)', '[\"автоматическое преобразование графической информации в цифровую форму\"]', NULL, NULL),
(186, 'ADDAC (analogdatadestributorandcomputer)', '[\"система распределения аналоговых данных и вычислительная система\"]', NULL, NULL),
(187, 'ADDAR (automaticdigitaldataacquisitionandrecording)', '[\"автоматический сбор и регистрация цифровых данных\"]', NULL, NULL),
(188, 'add/dropmultiplexer', '[\"мультиплексер ввода/вывода\"]', NULL, NULL),
(189, 'added', '[\"добавленный, дополненный\"]', NULL, NULL),
(190, 'added instruction kit', '[\"дополнительный набор команд\"]', NULL, NULL),
(191, 'ADDER (automaticdigitaldataerrorrecorder)', '[\"автоматический регистратор ошибок в цифровых данных\"]', NULL, NULL),
(192, 'adder', '[\"сумматор, суммирующее устройство\"]', NULL, NULL),
(193, 'add-in', '[\"расширение; дополнитлеьный встроенный ресурс\"]', NULL, NULL),
(194, 'add-inmemory', '[\"дополнительная память\"]', NULL, NULL),
(195, 'add-ins', '[\"добавки, вставки, надстройки\"]', NULL, NULL),
(196, 'adding', '[\"добавляющий, дополняющий\", \" добавление, дополнение\"]', NULL, NULL),
(197, 'addition (add)', '[\"дополнение; сложение, суммирование; увеличение\"]', NULL, NULL),
(198, 'additional', '[\"дополнительный\"]', NULL, NULL),
(199, 'additionrecord', '[\"добавляемая запись\"]', NULL, NULL),
(200, 'additive', '[\"аддитивный\"]', NULL, NULL),
(201, 'additive color', '[\"аддитивный цвет\"]', NULL, NULL),
(202, 'addl', '[\"сокр. от additional\"]', NULL, NULL),
(203, 'ADDMD (administration directory management domain)', '[\"административная область управления каталогом\"]', NULL, NULL),
(204, 'add-on', '[\" дополнение; элемент расширения\", \" добавляемый для расширения\"]', NULL, NULL),
(205, 'add-onboard', '[\"дополнительная плата; плата расширения\"]', NULL, NULL),
(206, 'add-on memory unit', '[\"добавочный блок памяти\"]', NULL, NULL),
(207, 'add-on module', '[\"добавляемый модуль, добавочный модуль, надстройка\"]', NULL, NULL),
(208, 'add-onprogram', '[\"надстройка; дополнение\"]', NULL, NULL),
(209, 'add-onunit (AOU)', '[\"дополнительное (дублирующее) устройство\"]', NULL, NULL),
(210, 'addpacked', '[\"сложение чисел в упакованном формате\"]', NULL, NULL),
(211, 'addprinter', '[\" установка принтера\", \" устанавливать принтер\"]', NULL, NULL),
(212, 'addr, ADDR', '[\"сокр. от address\"]', NULL, NULL),
(213, 'address', '[\"адрес; место нахождения; machine address машинный адрес\", \" адресовать \", \"указывать адрес хранения информации\",\"адресный; addressbus адресная шина\"]', NULL, NULL),
(214, 'addressadder', '[\"сумматор адресов\"]', NULL, NULL),
(215, 'addressarea', '[\"адрес доступа\"]', NULL, NULL),
(216, 'addressarithmeticansweringunit', '[\"арифметическое устройство обработки адресов\"]', NULL, NULL),
(217, 'address book', '[\"адресная книжка\"]', NULL, NULL),
(218, 'addressbuffer', '[\"буфер адреса; адресный буфер\"]', NULL, NULL),
(219, 'addressbus', '[\"шина адреса; адресная шина\"]', NULL, NULL),
(220, 'address calculation', '[\"вычисление адреса\"]', NULL, NULL),
(221, 'address character', '[\"символ адреса\"]', NULL, NULL),
(222, 'address class', '[\"класс адресов\"]', NULL, NULL),
(223, 'address code', '[\"код адреса\"]', NULL, NULL),
(224, 'address complete', '[\"завершение адреса\"]', NULL, NULL),
(225, 'address constant', '[\"адресная константа\"]', NULL, NULL),
(226, 'address control unit', '[\"блок управления адресом\"]', NULL, NULL),
(227, 'address counter', '[\"счетчик адреса\"]', NULL, NULL),
(228, 'address data strobe', '[\"строб кода адреса\"]', NULL, NULL),
(229, 'addressdecodelatch', '[\"фиксация дешифрованного (декодированного) адреса\"]', NULL, NULL),
(230, 'addressdecoder', '[\"дешифратор адреса\"]', NULL, NULL),
(231, 'addressdisplaysystem', '[\"система отображения адреса\"]', NULL, NULL),
(232, 'addressdriver', '[\"усилитель-формирователь адресов\"]', NULL, NULL),
(233, 'addressfetchcycle (AFC)', '[\"цикл выборки адреса\"]', NULL, NULL),
(234, 'addressfield', '[\"поле адреса; адресное поле\"]', NULL, NULL),
(235, 'address format', '[\"формат адреса\"]', NULL, NULL),
(236, 'address incomplete', '[\"неполнота адреса\"]', NULL, NULL),
(237, 'address indicating group', '[\"индикаторная группа адреса\"]', NULL, NULL),
(238, 'addresslatch', '[\"регистр-фиксатор адреса\"]', NULL, NULL),
(239, 'addressmapping', '[\"отображение адреса; преобразование логических адресов в абсолютные\"]', NULL, NULL),
(240, 'addressmark', '[\"метка адреса, маркер адреса\"]', NULL, NULL),
(241, 'address marker', '[\"адресный маркер\"]', NULL, NULL),
(242, 'address modification', '[\"модификация адреса\"]', NULL, NULL),
(243, 'address path', '[\"адресный путь\"]', NULL, NULL),
(244, 'address pointer', '[\"указатель адреса\"]', NULL, NULL),
(245, 'address range', '[\"диапазон адресов\"]', NULL, NULL),
(246, 'address reference', '[\"адресная ссылка\"]', NULL, NULL),
(247, 'addressregister', '[\"регистр адреса; адресный регистр\"]', NULL, NULL),
(248, 'addressrelocation', '[\"настройка адресов\"]', NULL, NULL),
(249, 'addressresolutionprotocol', '[\"протокол переопределения адреса (в Internet)\"]', NULL, NULL),
(250, 'addressspace', '[\"адресное пространство\"]', NULL, NULL),
(251, 'addresstranslation', '[\"трансляция адреса\"]', NULL, NULL),
(252, 'addresstranslationcache (ATC)', '[\"кэш-память преообразования адресов\"]', NULL, NULL),
(253, 'addresstype', '[\"адрес доступа\"]', NULL, NULL),
(254, 'addressword', '[\"адресное слово\"]', NULL, NULL),
(255, 'addressable', '[\" имеющий доступный адрес\", \" адресуемый\"]', NULL, NULL),
(256, 'addressablepoint', '[\"адресуемая точка\"]', NULL, NULL),
(257, 'addressablelatch', '[\"адресуемый регистратор-фиксатор\"]', NULL, NULL),
(258, 'addressablememory', '[\"адресуемая память\"]', NULL, NULL),
(259, 'addressee', '[\"адресат (получатель сообщения в сети)\"]', NULL, NULL),
(260, 'addresser', '[\"отправитель информации\"]', NULL, NULL),
(261, 'addressing', '[\" адресация\", \" способ адресации\"]', NULL, NULL),
(262, 'addressing capacity', '[\"диапазон адресации\"]', NULL, NULL),
(263, 'addressing level', '[\"уровень адресации\"]', NULL, NULL),
(264, 'addressing method', '[\"метод адресации\"]', NULL, NULL),
(265, 'addressing mode', '[\"способ адресации\"]', NULL, NULL),
(266, 'adequacy', '[\" достаточность\", \" соответствие, адекватность;\"]', NULL, NULL),
(267, 'adequacyofdata', '[\"достоверность данных\"]', NULL, NULL),
(268, 'adequate', '[\"адекватный; достаточный\"]', NULL, NULL),
(269, 'adjacentchannel', '[\"соседний канал\"]', NULL, NULL),
(270, 'adjacentchannelattenuation', '[\"избирательность по соседнему каналу\"]', NULL, NULL),
(271, 'adjust', '[\" коррекция\", \" (от)регулировать, настраивать; устанавливать\",\"корректировать\",\"модифицировать\"]', NULL, NULL),
(272, 'adjustable', '[\"регулируемый\"]', NULL, NULL),
(273, 'adjusted', '[\"отредактированный; скорректированный; adjusteddata отредактированные данные\"]', NULL, NULL),
(274, 'adjustment', '[\"регулирование\"]', NULL, NULL),
(275, 'administering', '[\" администрирование\", \" администрирующий\"]', NULL, NULL),
(276, 'administrating', '[\" управление\", \" управляющий\"]', NULL, NULL),
(277, 'administration', '[\"управление\"]', NULL, NULL),
(278, 'administrative', '[\"административный, управляющий\"]', NULL, NULL),
(279, 'administrator', '[\"администратор\"]', NULL, NULL),
(280, 'admissible', '[\"допустимый\"]', NULL, NULL),
(281, 'admissible character', '[\"допустимый символ\"]', NULL, NULL),
(282, 'admissible error', '[\"допустимая ошибка\"]', NULL, NULL),
(283, 'admission', '[\"доступ, вход; gain to admission получить доступ к\"]', NULL, NULL),
(284, 'admit', '[\"допускать\"]', NULL, NULL),
(285, 'admittance', '[\"доступ\"]', NULL, NULL),
(286, 'adobe type', '[\" формат шрифтов фирмы Adobe (другоеназвание - PostScript type 1 или type 1)\"]', NULL, NULL),
(287, 'adobetypealign', '[\"программа преобразования шрифтов\"]', NULL, NULL),
(288, 'Adope type manager (ATM)', '[\"менеджер шрифтов системы Adobe\"]', NULL, NULL),
(289, 'advance', '[\" продвижение (вперед), прогресс\", \" продвигаться, идти вперед\"]', NULL, NULL),
(290, 'advanced', '[\" имеющий опыт работы в определенной области\", \" продвинутый; усложненный, усиленный, улучшенный; расширенный;\",\"дополнительный\"]', NULL, NULL),
(291, 'advancedbyte-oriented', '[\"ориентированный на побайтовую обработку\"]', NULL, NULL),
(292, 'advanced color enhancement (ACE)', '[\"технология улучшения цветов\"]', NULL, NULL),
(293, 'advanced computational element', '[\"усоврешенстовованный вычислительный элемент\"]', NULL, NULL),
(294, 'advanced computing environment', '[\"перспективная вычислительная среда\"]', NULL, NULL),
(295, 'advanceddatalinkcontroller', '[\"контроллер линии передачи данных с расширенными возможностями\"]', NULL, NULL),
(296, 'advanceddirectmemoryaccess (ADMA)', '[\"усовершенствованный доступ к памяти\"]', NULL, NULL),
(297, 'advanceddiskmanager', '[\"усовершенствованный менеджер диска (драйвер)\"]', NULL, NULL),
(298, 'advancedfeature', '[\"средства расширения\"]', NULL, NULL),
(299, 'advancedsettings', '[\"дополнительные настройки\"]', NULL, NULL),
(300, 'advantage', '[\"преимущество\"]', NULL, NULL),
(301, 'advertise', '[\"рекламировать\"]', NULL, NULL),
(302, 'advertisement', '[\"объявление, реклама\"]', NULL, NULL),
(303, 'advice', '[\" совет\", \" советовать; уведомлять\"]', NULL, NULL),
(304, 'adviser', '[\"советник, консультант\"]', NULL, NULL),
(305, 'advisory', '[\"советующий, консультурующий\"]', NULL, NULL),
(306, 'advisoryroutine', '[\"программа-консультант\"]', NULL, NULL),
(307, 'after', '[\" после, спустя, затем, потом\", \" последующий\"]', NULL, NULL),
(308, 'afterframecontents', '[\"примечания или сноски в конце фрейма\"]', NULL, NULL),
(309, 'again', '[\"снова\"]', NULL, NULL),
(310, 'against', '[\"против\"]', NULL, NULL),
(311, 'agent', '[\"агент, невидимая для пользователя вспомогательная программа\"]', NULL, NULL),
(312, 'aggregation', '[\"обобщение\"]', NULL, NULL),
(313, 'ahead', '[\"вперед; впереди\"]', NULL, NULL),
(314, 'aid', '[\" помощь, содействие; пособие\", \" помогать; облегчать\"]', NULL, NULL),
(315, 'aidant', '[\"дополнительное вспомогательное средство\"]', NULL, NULL),
(316, 'aid debugging program', '[\"вспомогательная отладочная программа\"]', NULL, NULL),
(317, 'aim', '[\" цель, намерение\", \" нацеливать(ся)\"]', NULL, NULL),
(318, 'aimless', '[\"бесцельный\"]', NULL, NULL),
(319, 'airbrush', '[\"пульверизатор, аэрограф\"]', NULL, NULL),
(320, 'air-waves', '[\"радиоволны\"]', NULL, NULL),
(321, 'alarm', '[\"тревога; сигнал тревоги; звуковой сигнал, оповещающий о чем-либо\"]', NULL, NULL),
(322, 'alarming', '[\"тревожный\"]', NULL, NULL),
(323, 'alert', '[\" предупреждение\", \" предупредить, предупреждать\"]', NULL, NULL),
(324, 'alert always', '[\"постоянная готовность\"]', NULL, NULL),
(325, 'alerting', '[\"сигнальное оповещение\"]', NULL, NULL),
(326, 'alertmessage', '[\"предупреждение\"]', NULL, NULL),
(327, 'algebra', '[\"алгебра\"]', NULL, NULL),
(328, 'algebraic(al)', '[\"алгебраический\"]', NULL, NULL),
(329, 'algebraiccomputer', '[\"алгебраическая ЭВМ\"]', NULL, NULL),
(330, 'algorism', '[\" десятеричная (арабская) система счисления\", \" алгоритм\"]', NULL, NULL),
(331, 'algorithm', '[\"алгоритм; algorithmforpatternrecognition аглоритм распознавания образов\"]', NULL, NULL),
(332, 'algorithmbranch', '[\"ветвь алгоритма\"]', NULL, NULL),
(333, 'algorithmerror', '[\"ошибка алгоритма\"]', NULL, NULL),
(334, 'algorithmic', '[\"алгоритмический\"]', NULL, NULL),
(335, 'algorithmiclanguage', '[\"алгоритмический язык\"]', NULL, NULL),
(336, 'algorithm validation', '[\"проверка (доказательство) правильности алгоритма\"]', NULL, NULL),
(337, 'alias', '[\"псевдоним\"]', NULL, NULL),
(338, 'aliasing', '[\"ступенчатость (линий); наложение спектров; совмещение имен\"]', NULL, NULL),
(339, 'align', '[\"выстраивать в линию; выравнивать (строки)\"]', NULL, NULL),
(340, 'aligncartridges', '[\"юстировка картриджей\"]', NULL, NULL),
(341, 'alignment', '[\"группировка; расположение в линию; выравнивание (строк);\"]', NULL, NULL),
(342, 'alignment to baseline', '[\"выравнивание по базовой линии\"]', NULL, NULL),
(343, 'allocate', '[\"размещать, распределять, выделять (ресурсы)\"]', NULL, NULL),
(344, 'allocated', '[\"распределенный\"]', NULL, NULL),
(345, 'allocatedcluster', '[\"распределенные (или занятые) кластеры\"]', NULL, NULL),
(346, 'allocation', '[\"размещение, выделение (памяти, ресурсов);\"]', NULL, NULL),
(347, 'allocationerrorforfile', '[\"ошибка распределения для файла\"]', NULL, NULL),
(348, 'allocationmap', '[\"таблица распределения\"]', NULL, NULL),
(349, 'allocation unit', '[\"кластер, выделяемый блок, единица распределения\"]', NULL, NULL),
(350, 'allow', '[\"допустить, разрешить, позволить\"]', NULL, NULL),
(351, 'allow distortion', '[\"нарушать пропорции\"]', NULL, NULL),
(352, 'allowed', '[\"допускаемый, позволенный\"]', NULL, NULL),
(353, 'allowediting', '[\"разрешать редактирование\"]', NULL, NULL),
(354, 'allowfreedragging', '[\"буксировка разрешена\"]', NULL, NULL),
(355, 'allowprintspooling', '[\"печать через буфер разрешена\"]', NULL, NULL),
(356, 'allowwithin', '[\"разрешить разрыв\"]', NULL, NULL),
(357, 'all-purpose', '[\"универсальный\"]', NULL, NULL),
(358, 'all-purposecomputer', '[\"универсальная ЭВМ\"]', NULL, NULL),
(359, 'alone', '[\"в одиночку\"]', NULL, NULL),
(360, 'alphachannel', '[\"альфа-канал, канал прозрачности\"]', NULL, NULL),
(361, 'alphatesting', '[\"альфа-тестирование\"]', NULL, NULL),
(362, 'alphabet', '[\"алфавит\"]', NULL, NULL),
(363, 'alphabetstring', '[\"текстовая строка\"]', NULL, NULL),
(364, 'alphabetic(al)', '[\" алфавитный\", \" буквенный\"]', NULL, NULL),
(365, 'alphabeticalrubrication', '[\"литерация\"]', NULL, NULL),
(366, 'alphamericто', '[\"же, что и alphanumerical\"]', NULL, NULL),
(367, 'alphanumerical', '[\"буквенно-цифровой, алфавитно-цифровой; текстовый\"]', NULL, NULL),
(368, 'alphanumericcharacter', '[\"тестовый символ\"]', NULL, NULL),
(369, 'alphanumericcharacterset', '[\"набор буквенно-цифровых знаков\"]', NULL, NULL),
(370, 'alphanumericdisplay', '[\"алфавитно-цифровой дисплей\"]', NULL, NULL),
(371, 'alphanumerickeyboard', '[\"буквенно-цифровая клавиатура\"]', NULL, NULL),
(372, 'alphanumericsort', '[\"сортировка по алфавиту\"]', NULL, NULL),
(373, 'alphascope', '[\"устройство для вывода буквенной информации на дисплей ЭВМ\"]', NULL, NULL),
(374, 'already', '[\"уже\"]', NULL, NULL),
(375, 'alreadyexist', '[\"уже существует\"]', NULL, NULL),
(376, 'alreadyinstalled', '[\"уже установлена\"]', NULL, NULL),
(377, 'alreadyconnected', '[\"соединение произведено\"]', NULL, NULL),
(378, 'also', '[\"также, тоже\"]', NULL, NULL),
(379, 'alt', '[\"клавиша в компьютерах (изменяет смысл клавиш, нажимаемых вместе с ней)\"]', NULL, NULL),
(380, 'alternate', '[\" альтернативный\", \" то же, что и alt\"]', NULL, NULL),
(381, 'alternation', '[\"изменение; преобразование\"]', NULL, NULL),
(382, 'alternative', '[\" альтернатива; выбор действия\", \" вариантный; альтернативный; взаимоисключающий\"]', NULL, NULL),
(383, 'alternativemode', '[\"режим попеременного доступа\"]', NULL, NULL),
(384, 'altsysfontormatic', '[\"программа преобразования шрифтов\"]', NULL, NULL),
(385, 'altsysmetamorphosis', '[\"программа преобразовнаия шрифтов\"]', NULL, NULL),
(386, 'always', '[\"всегда\"]', NULL, NULL),
(387, 'amass', '[\"накопить, собрать\"]', NULL, NULL),
(388, 'amend', '[\"исправлять, исправить, вносить поправки\"]', NULL, NULL),
(389, 'amendment', '[\" исправленная версия (редакция)\", \" изменение; поправка\"]', NULL, NULL),
(390, 'amendmentrecord', '[\"запись файла изменений\"]', NULL, NULL),
(391, 'amount', '[\"количество\"]', NULL, NULL),
(392, 'amountreadlessthansizeheader', '[\"считано меньше, чем указано в заголовке\"]', NULL, NULL),
(393, 'ampere', '[\"ампер\"]', NULL, NULL),
(394, 'ampersand', '[\"амперсанд, знак (символ) \"\"\"]', NULL, NULL),
(395, 'ample', '[\"достаточный\"]', NULL, NULL),
(396, 'amplification', '[\"усиление\"]', NULL, NULL),
(397, 'amplifier', '[\"усилитель\"]', NULL, NULL),
(398, 'analogamplifier', '[\"аналоговый усилитель\"]', NULL, NULL),
(399, 'amplify', '[\"усиливать, усилить\"]', NULL, NULL),
(400, 'amply', '[\"достаточно\"]', NULL, NULL),
(401, 'analog', '[\" аналог\", \" аналоговый;\",\"представляющий информацию посредством непрерывно изменяющихся величин (амплитуды, фазы, частоты)\"]', NULL, NULL),
(402, 'analogamplifier', '[\"аналоговый усилитель\"]', NULL, NULL),
(403, 'analog audio', '[\"аналоговая запись звуковых сигналов\"]', NULL, NULL),
(404, 'analogboundarycell', '[\"аналоговый периферийный элемент\"]', NULL, NULL),
(405, 'analogcircuit', '[\"аналоговая схема\"]', NULL, NULL),
(406, 'analog computer', '[\"аналоговая вычислительная машина\"]', NULL, NULL),
(407, 'analog data form', '[\"аналоговая форма данных\"]', NULL, NULL),
(408, 'analogdatahandlingassembly (ADHA)', '[\"система команд для обработки аналоговых данных\"]', NULL, NULL),
(409, 'analogdatahandlingsystem (ADHS)', '[\"система обработки аналоговых данных\"]', NULL, NULL),
(410, 'analogdelayunit', '[\"аналоговая линия задержки\"]', NULL, NULL),
(411, 'analogdevice', '[\"аналоговое утсройство\"]', NULL, NULL),
(412, 'analog-digital', '[\"аналого-цифровой\"]', NULL, NULL),
(413, 'analog-digital conversion', '[\"преобразование из аналоговой формы в цифровую\"]', NULL, NULL),
(414, 'analog-digitalconverter (ADC)', '[\"аналого-цифровой преобразователь (АПЦ)\"]', NULL, NULL),
(415, 'analogdisplayunit', '[\"блок отображения аналоговых сигналов\"]', NULL, NULL),
(416, 'analogexpansionbus', '[\"аналоговая шина расширения\"]', NULL, NULL),
(417, 'analogformation', '[\"аналоговое моделирование\"]', NULL, NULL),
(418, 'analogfunctiongenerator', '[\"генератор аналоговой функции, аналоговый функциональный преобразователь\"]', NULL, NULL),
(419, 'analoginput', '[\"аналоговый вход\"]', NULL, NULL),
(420, 'analoginputmodule', '[\"аналоговый входной модуль\"]', NULL, NULL),
(421, 'analoginterface', '[\"аналоговый интерфейс\"]', NULL, NULL),
(422, 'analogoutput', '[\"аналоговый вывод\"]', NULL, NULL),
(423, 'analogprogramtape', '[\"лента с аналоговой записью программы\"]', NULL, NULL),
(424, 'analogrecorder', '[\"устройство регистрации аналоговых сигналов\"]', NULL, NULL),
(425, 'analogsignal', '[\"аналоговый сигнал\"]', NULL, NULL),
(426, 'analog test input', '[\"вход (для) аналогового тестирования\"]', NULL, NULL),
(427, 'analog-to-digital, analog to digital', '[\"аналого-цифровой\"]', NULL, NULL),
(428, 'analog to digital converter (ADC)', '[\"аналого-цифровой преобразователь (АЦП)\"]', NULL, NULL),
(429, 'analogtranslator', '[\"аналоговый транслятор\"]', NULL, NULL),
(430, 'analogue', '[\" аналог; аналоговое устройство, моделирующее устройство\", \" то же, что и analog;\",\"моделирующая система\"]', NULL, NULL),
(431, 'analogue computer', '[\"тоже, чтои analog computer\"]', NULL, NULL),
(432, 'analogy', '[\"аналогия\"]', NULL, NULL),
(433, 'analyse', '[\"(про)анализировать\"]', NULL, NULL),
(434, 'analysis', '[\"анализ, разбор, исследование\"]', NULL, NULL),
(435, 'analyst', '[\"аналитик\"]', NULL, NULL),
(436, 'analytical', '[\"аналитический\"]', NULL, NULL),
(437, 'analyze', '[\"(про)анализировать\"]', NULL, NULL),
(438, 'analyzer', '[\"анализатор\"]', NULL, NULL),
(439, 'analyzing', '[\"анализирование; анализ;\"]', NULL, NULL),
(440, 'analyzingtheallocationtables', '[\"анализ таблицы размещения файлов\"]', NULL, NULL),
(441, 'analyzing directory structure', '[\"анализ структуры каталога\"]', NULL, NULL),
(442, 'ancestor', '[\"предок\"]', NULL, NULL),
(443, 'ancestor directory', '[\"каталог верхнего уровня\"]', NULL, NULL),
(444, 'anchor', '[\" привязка\", \" связь;\",\"зацепить\"]', NULL, NULL),
(445, 'anchored', '[\"фиксированный\"]', NULL, NULL),
(446, 'anchorpoint', '[\"точка привязки\"]', NULL, NULL),
(447, 'and', '[\"и\"]', NULL, NULL),
(448, 'angle', '[\"угол\"]', NULL, NULL),
(449, 'anglebetweenitems', '[\"угол между элементами\"]', NULL, NULL),
(450, 'angleforcrosshatchlines', '[\"угол наклона линии штриховки\"]', NULL, NULL),
(451, 'angleforpattern', '[\"угол наклона шаблона\", \"символ \'больше\' (\'\') или \'меньше\' (\'\');\",\"угловые скобки\"]', NULL, NULL),
(452, 'angular', '[\"угловой\"]', NULL, NULL),
(453, 'angulardisplayunit', '[\"блок отображения угловой информации\"]', NULL, NULL),
(454, 'animation', '[\" мультипликация, анимация\", \" анимационный\"]', NULL, NULL),
(455, 'animation path', '[\"анимационная последовательность\"]', NULL, NULL),
(456, 'ANN', '[\"то же, что и annotation\"]', NULL, NULL),
(457, 'annex', '[\"приложение\"]', NULL, NULL),
(458, 'annex memory', '[\"буферная память\"]', NULL, NULL),
(459, 'annihilate', '[\"уничтожать, уничтожить\"]', NULL, NULL),
(460, 'anihilation', '[\"уничтожение\"]', NULL, NULL),
(461, 'annotate', '[\"комментировать, снабжать примечаниями или комментариями\"]', NULL, NULL),
(462, 'annotated', '[\"снабженный примечаниями или комментариями\"]', NULL, NULL),
(463, 'annotation', '[\"аннотация; комментарий; примечание\"]', NULL, NULL),
(464, 'annotationmark', '[\"выделение (отметка) аннотации\"]', NULL, NULL),
(465, 'annotationtext', '[\"текст аннотации\"]', NULL, NULL),
(466, 'announce', '[\"объявлять, объявить; заявлять; сообщать\"]', NULL, NULL),
(467, 'announcement', '[\"объявление, сообщение\"]', NULL, NULL),
(468, 'annoyware', '[\"условно-бесплатное программное обеспечение, напоминающее пользователю о необходимости заплатить за продукт\"]', NULL, NULL),
(469, 'annual', '[\"годовой, ежегодный\"]', NULL, NULL),
(470, 'annually', '[\"ежегодно\"]', NULL, NULL),
(471, 'annul', '[\"аннулировать\"]', NULL, NULL),
(472, 'annulment', '[\"аннулирование\"]', NULL, NULL),
(473, 'anomalous', '[\"аномальный\"]', NULL, NULL),
(474, 'anomaly', '[\"аномалия, отклонение\"]', NULL, NULL),
(475, 'anonymity', '[\"анонимность\"]', NULL, NULL),
(476, 'anonymous', '[\"анонимный\"]', NULL, NULL),
(477, 'another', '[\"другой\"]', NULL, NULL),
(478, 'answer', '[\"ответ; реакция\"]', NULL, NULL),
(479, 'aswertoademand', '[\"ответ на запрос\"]', NULL, NULL),
(480, 'automaticanswer', '[\"автоматический ответ\", \" отвечать\"]', NULL, NULL),
(481, 'answerbackdrum', '[\"автоответчик\"]', NULL, NULL),
(482, 'answering', '[\"ответ; реакция\"]', NULL, NULL),
(483, 'answeringmachine', '[\"телефон-ответчик, автоответчик\"]', NULL, NULL),
(484, 'answerkey', '[\"клавиша ответа\"]', NULL, NULL),
(485, 'answerscreen', '[\" кадр ответа\", \" экран ответа\"]', NULL, NULL),
(486, 'antenna', '[\"антенна\"]', NULL, NULL),
(487, 'anti', '[\"против-, анти-\"]', NULL, NULL),
(488, 'anti-aliasing', '[\"антидискретизация, сглаживание (кривых)\"]', NULL, NULL),
(489, 'anti-aliasingfilter', '[\"фильтр защиты от наложения спектров при наложении аналоговых сигналов\"]', NULL, NULL),
(490, 'anti-glare', '[\"антибликовый (об экране монитора)\"]', NULL, NULL),
(491, 'anti-reflection', '[\"антиотражающий (экран монитора)\"]', NULL, NULL),
(492, 'anticipate', '[\"ожидать; пердупреждать\"]', NULL, NULL),
(493, 'anticipation', '[\"ожидание; предупреждение, упреждение\"]', NULL, NULL),
(494, 'anticipatorymode', '[\"режим с упреждением\"]', NULL, NULL),
(495, 'antistatic', '[\"антистатический (об экране монитора)\"]', NULL, NULL),
(496, 'antiviral', '[\"антивирусный\"]', NULL, NULL),
(497, 'antivirus', '[\" антивирус\", \" противовирусный, антивирусный\"]', NULL, NULL),
(498, 'antivirusprogram', '[\"антивирусная программа\"]', NULL, NULL),
(499, 'any', '[\"любой; какой-нибудь;\"]', NULL, NULL),
(500, 'anykey', '[\"любая клавиша\"]', NULL, NULL),
(501, 'anywhere', '[\"где бы то ни было, в любом месте\"]', NULL, NULL),
(502, 'Apache', '[\"Веб-сервер\"]', NULL, NULL),
(503, 'appeal', '[\" обращение\", \" обращаться, призывать\"]', NULL, NULL),
(504, 'appear', '[\"появляться, появиться\"]', NULL, NULL),
(505, 'appearance', '[\"внешний вид; оформление\"]', NULL, NULL),
(506, 'append', '[\"добавлять; присоединять\"]', NULL, NULL),
(507, 'appendage', '[\"дополнительное приспособление\"]', NULL, NULL),
(508, 'APPEND', '[\"внешняя команда DOS\"]', NULL, NULL),
(509, 'appendix', '[\"добавление, приложение\"]', NULL, NULL),
(510, 'appliance', '[\"прибор\"]', NULL, NULL),
(511, 'applicabe', '[\"применимый\"]', NULL, NULL),
(512, 'application', '[\" приложение; применение\", \" (прикладная) программа;\",\"прикладной\"]', NULL, NULL),
(513, 'applicationbinaryinterface', '[\"двоичный интерфейс приложения\"]', NULL, NULL),
(514, 'audible', '[\"слышимый\"]', NULL, NULL),
(515, 'audience', '[\"аудитория, публика\"]', NULL, NULL),
(516, 'audio', '[\" аудио\", \" звук;\",\"звуковой; мультимедийный; речевой\"]', NULL, NULL),
(517, 'audioadapter', '[\"звуковая плата\"]', NULL, NULL),
(518, 'audiodata', '[\"аудиоданные\"]', NULL, NULL),
(519, 'audiofile', '[\"аудиофайл\"]', NULL, NULL),
(520, 'audioformat', '[\"формат представления аудиоданных\"]', NULL, NULL),
(521, 'audiointerfaceboard', '[\"интерфейсная звуковая плата\"]', NULL, NULL),
(522, 'audiomixer', '[\"смеситель аудиосигналов (от различных источников)\"]', NULL, NULL),
(523, 'audioresponseequipment', '[\"аппаратура речевого вывода информации\"]', NULL, NULL),
(524, 'audio response unit', '[\"устройство речевого вывода\"]', NULL, NULL),
(525, 'audiosignal', '[\"аудиосигнал\"]', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Jurabek', 'bjr061981@gmail.com', NULL, '$2y$10$rzFKhE1G7dAQTrhchg/yuenIbKiXm64gmuRw1IsSQlnLS4SHnmc5G', NULL, '2021-08-09 08:55:00', '2021-08-09 08:55:00');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Индексы таблицы `ruen`
--
ALTER TABLE `ruen`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `ruen`
--
ALTER TABLE `ruen`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=526;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
