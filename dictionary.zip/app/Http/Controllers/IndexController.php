<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Auth;
use App\Models\Ruen;
use Config;
use Arr;

class IndexController extends SiteController
{
    public function __construct(){
		$this->template = env('THEME').'.index';
	}
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$this->title =  $this->keywords =  $this->meta_desc =  'Главная страница';
		$ruen =$this->getRuens();
        $ruen = view(config('settings.theme').'.content',compact('ruen'))->render();
        $this->vars = Arr::add($this->vars,'content',$ruen);
        return $this->renderOutput();
    }

	public function getRuens(){
		$ruen = Ruen::where('enname','!=','NULL')
				->orderBy('created_at', 'desc')
				->inRandomOrder()
				->limit(Config::get('settings.paginate_index'))
				// ->first();
				->get();
				// dd($ruen->runame);
		return $ruen;
	}





	public function getEtog(Request $request){
		$data = $request->except('_token');
		$ruen = Ruen::where('id', $data['id'])->first();
		// dd($ruen);


		// $search = $request->myCountry;
		$this->title =  $this->keywords =  $this->meta_desc =  $ruen->enname;
        $ruen = view(config('settings.theme').'.search',compact('ruen'))->render();
        $this->vars = Arr::add($this->vars,'content',$ruen);
        return $this->renderOutput();


	}


	public function getSave(Request $request){
	$data = $request->except('_token');
	$cod = Ruen::where('id', $data['par_id'])
                ->update(['runame' => $data['runame']]);
	if($cod) {return ['status' => 'Сохранено!'];	}

	}




	public function getSearch(Request $request){
		$search = $request->search;
		if(iconv_strlen($search,'UTF-8') >2){
			$emloyees = $this->getAll($search);
		}
		$response = [];
		foreach ($emloyees as $emloyee) {
			$response[] = array(
				"value" => $emloyee->id,
				"label" => $emloyee->enname
			);
		}
		echo json_encode($response);
		exit;
	}


	public function getAll($search){
		$all =	Ruen::select('id','enname')
				->where('enname', 'like', '%'.$search.'%')
				->limit(Config::get('settings.paginate_index'))
				->get();
		return $all;
	}

}
