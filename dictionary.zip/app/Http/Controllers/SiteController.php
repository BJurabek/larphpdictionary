<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ruen;
use Config;
use Cache;
use Arr;
use Str;


class SiteController extends Controller
{

    protected $keywords;
    protected $meta_desc;
    protected $title;

    protected $template;
    protected $vars = array();


    public function __construct( ){}

	protected function renderOutput(){
	$this->vars = Arr::add($this->vars,'keywords',$this->keywords);
		$this->vars = Arr::add($this->vars,'meta_desc',$this->meta_desc);
		$this->vars = Arr::add($this->vars,'title',$this->title);
	return view($this->template)->with($this->vars);
	}


}

