<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers as Adress;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [Adress\IndexController::class, 'index']);

Route::get('/emloyees/getEtog/', [Adress\IndexController::class, 'index']);
Route::get('/emloyees/getSearch/', [Adress\IndexController::class, 'index']);
Route::get('/save/', [Adress\IndexController::class, 'index']);
Route::post('/emloyees/getEtog/', [Adress\IndexController::class, 'getEtog'])->name('emloyees.getEtog');
Route::post('/emloyees/getSearch/', [Adress\IndexController::class, 'getSearch'])->name('emloyees.getSearch');
Route::post('/save/', [Adress\IndexController::class, 'getSave'])->name('save');

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';
